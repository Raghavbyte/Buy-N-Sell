package com.example.farm_to_kitchen;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
public class MyAdsCardView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_ads_card_view);
    }
}